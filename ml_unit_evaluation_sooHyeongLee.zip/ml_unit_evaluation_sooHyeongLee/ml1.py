import pandas as pd
name=['A', 'B', 'C', 'D', 'E', 'F', 'G']
horse=[130, 250, 190, 300, 210, 220, 170]
efficiency= [16.3, 10.2, 11.1, 7.1, 12.1, 13.2, 14.2]
T = pd.DataFrame({'name': name, 'horse power': horse,'efficiency': efficiency})
T.set_index('name', inplace=True)
print(T)


import pandas as pd
from sklearn.linear_model import LinearRegression

# DataFrame 생성
name = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
horse = [130, 250, 190, 300, 210, 220, 170]
efficiency = [16.3, 10.2, 11.1, 7.1, 12.1, 13.2, 14.2]
T = pd.DataFrame({'name': name, 'horse power': horse, 'efficiency': efficiency})
T.set_index('name', inplace=True)

# LinearRegression 모델 학습
X = T[['horse power']]
y = T['efficiency']
model = LinearRegression()
model.fit(X, y)

# 계수, 절편, 예측 점수 출력
coefficients = model.coef_
intercept = model.intercept_
score = model.score(X, y)

print("계수:", coefficients)
print("절편:", intercept)
print("예측 점수:", score)

import pandas as pd
import warnings
from sklearn.linear_model import LinearRegression

# DataFrame 생성
name = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
horse_power = [130, 250, 190, 300, 210, 220, 170]
efficiency = [16.3, 10.2, 11.1, 7.1, 12.1, 13.2, 14.2]
T = pd.DataFrame({'name': name, 'horse power': horse_power, 'efficiency': efficiency})
T.set_index('name', inplace=True)

# 경고 메시지 숨기기
warnings.filterwarnings("ignore")

# LinearRegression 모델 학습
X = T[['horse power']]
y = T['efficiency']
model = LinearRegression()
model.fit(X, y)

# 280 마력 자동차의 연비 예측
new_horse_power = 280
predicted_efficiency = model.predict([[new_horse_power]])[0]

print("280 마력 자동차의 예상 연비: {:.2f} km/l".format(predicted_efficiency))