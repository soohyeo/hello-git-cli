import pandas as pd
name=['A', 'B', 'C', 'D', 'E', 'F', 'G']
horse=[130, 250, 190, 300, 210, 220, 170]
weight=[1900, 2600, 2200, 2900, 2400, 2300, 2100]
efficiency= [16.3, 10.2, 11.1, 7.1, 12.1, 13.2, 14.2]
T = pd.DataFrame({'name': name, 'horse power': horse, 'weight': weight,'efficiency': efficiency})
T.set_index('name', inplace=True)
print(T)


import pandas as pd
from sklearn.linear_model import LinearRegression

# DataFrame 생성
name = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
horse_power = [130, 250, 190, 300, 210, 220, 170]
weight = [1900, 2600, 2200, 2900, 2400, 2300, 2100]
efficiency = [16.3, 10.2, 11.1, 7.1, 12.1, 13.2, 14.2]
T = pd.DataFrame({'name': name, 'horse power': horse_power, 'weight': weight, 'efficiency': efficiency})
T.set_index('name', inplace=True)

# LinearRegression 모델 학습
X = T[['horse power', 'weight']]
y = T['efficiency']
model = LinearRegression()
model.fit(X, y)

# 계수, 절편, 예측 점수 출력
coefficients = model.coef_
intercept = model.intercept_
score = model.score(X, y)

print("계수:", coefficients)
print("절편:", intercept)
print("예측 점수:", score)

import pandas as pd
import warnings
from sklearn.linear_model import LinearRegression

# DataFrame 생성
name = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
horse_power = [130, 250, 190, 300, 210, 220, 170]
weight = [1900, 2600, 2200, 2900, 2400, 2300, 2100]
efficiency = [16.3, 10.2, 11.1, 7.1, 12.1, 13.2, 14.2]
T = pd.DataFrame({'name': name, 'horse power': horse_power, 'weight': weight, 'efficiency': efficiency})
T.set_index('name', inplace=True)

# 경고 메시지 숨기기
warnings.filterwarnings("ignore")

# LinearRegression 모델 학습
X = T[['horse power', 'weight']]
y = T['efficiency']
model = LinearRegression()
model.fit(X, y)

# 280 마력 자동차의 연비 예측
new_horse_power = 280
new_weight = 2500  # 가상의 값으로 설정
predicted_efficiency = model.predict([[new_horse_power, new_weight]])[0]

print("280 마력 자동차의 예상 연비: {:.2f} km/l".format(predicted_efficiency))

import pandas as pd
import seaborn as sns

# DataFrame 생성
name = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
horse_power = [130, 250, 190, 300, 210, 220, 170]
weight = [1900, 2600, 2200, 2900, 2400, 2300, 2100]
efficiency = [16.3, 10.2, 11.1, 7.1, 12.1, 13.2, 14.2]
T = pd.DataFrame({'name': name, 'horse power': horse_power, 'weight': weight, 'efficiency': efficiency})
T.set_index('name', inplace=True)

# Pairplot 그리기
sns.pairplot(T)

# 그래프 출력
import matplotlib.pyplot as plt
plt.show()

import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
name=['A', 'B', 'C', 'D', 'E', 'F', 'G']
horse=[130, 250, 190, 300, 210, 220, 170]
weight=[1900,2600,2200,2900,2400,2300,2100]
efficiency= [16.3, 10.2, 11.1, 7.1, 12.1, 13.2, 14.2]
T = pd.DataFrame({'name': name, 'horse power': horse,'weight':weight,'efficiency': efficiency})
T.set_index('name',inplace=True)
corr=T.corr()
sns.heatmap(corr,annot=True)
plt.show()